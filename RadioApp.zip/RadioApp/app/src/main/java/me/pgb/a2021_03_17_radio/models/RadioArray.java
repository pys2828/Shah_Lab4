package me.pgb.a2021_03_17_radio.models;

public class RadioArray {
    private static String[] arr;

    public static RadioStation[] stations = {
            new RadioStation("http://stream.whus.org:8000/whusfm", "WHUS", "USA", "https://i2.wp.com/whus.org/wp-content/uploads/2020/03/whus.png?resize=500%2C400&ssl=1"),
            new RadioStation("http://162.244.80.106:11011/stream", "WBIM", "USA", "https://static-media.streema.com/media/cache/49/c3/49c370260069c46971c0ce48483bba20.jpg"),
            new RadioStation("http://crystalout.surfernetwork.com:8000/KSCL_MP3", "KSCL", "USA", "https://static-media.streema.com/media/cache/bc/4c/bc4c397c6f23780165896ef948fb14e8.jpg"),
    };

    public static String[] getRadioNames() {
        arr = new String[stations.length];
        for (int i = 0; i < stations.length; i++){
            arr[i] = stations[i].getName();
        }
        return arr;
    }

    public static String[] getRadioLink(){
        arr = new String[stations.length];
        for (int i = 0; i < stations.length; i++){
            arr[i] = stations[i].getStream();
        }
        return arr;
    }

    public static String[] getRadioImg(){
        arr = new String[stations.length];
        for (int i = 0; i < stations.length; i++){
            arr[i] = stations[i].getImage();
        }
        return arr;
    }

}


